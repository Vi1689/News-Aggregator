--
-- PostgreSQL database cluster dump
--

\restrict slOhFDELPbAkgRMWZtqnh3YcymLumREvcUkyCmV7aZQ3FSz9MZ8MhlpSZRCbuuF

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE news_user;
ALTER ROLE news_user WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:vYigIdAZpp1EDPWw9Ee36A==$7wqvRgzE1reKA5ZSgZiAKo6fRgEUX+XRCdVHftgW7XM=:rI3qeI1eRgQxmjBIPg3KtbqQHD3K/49NVwqhHiZ9rmA=';

--
-- User Configurations
--








\unrestrict slOhFDELPbAkgRMWZtqnh3YcymLumREvcUkyCmV7aZQ3FSz9MZ8MhlpSZRCbuuF

--
-- PostgreSQL database cluster dump complete
--

