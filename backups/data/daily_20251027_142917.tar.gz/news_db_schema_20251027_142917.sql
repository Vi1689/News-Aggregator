--
-- PostgreSQL database dump
--

\restrict xm4I2YHWqBPMFIcqGYTTFdeEn80R3OZHVb7CncuoURk9XWiXrBnNh9eWyaNEeqa

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: news_user
--

CREATE TABLE public.comments (
    comment_id integer NOT NULL,
    post_id integer,
    nickname character varying(255) NOT NULL,
    parent_comment_id integer,
    text text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    likes_count integer DEFAULT 0
);


ALTER TABLE public.comments OWNER TO news_user;

--
-- Name: active_users; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.active_users AS
 SELECT comments.nickname,
    count(*) AS comments_count
   FROM public.comments
  GROUP BY comments.nickname;


ALTER TABLE public.active_users OWNER TO news_user;

--
-- Name: authors; Type: TABLE; Schema: public; Owner: news_user
--

CREATE TABLE public.authors (
    author_id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.authors OWNER TO news_user;

--
-- Name: authors_author_id_seq; Type: SEQUENCE; Schema: public; Owner: news_user
--

CREATE SEQUENCE public.authors_author_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.authors_author_id_seq OWNER TO news_user;

--
-- Name: authors_author_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: news_user
--

ALTER SEQUENCE public.authors_author_id_seq OWNED BY public.authors.author_id;


--
-- Name: avg_comments_per_post; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.avg_comments_per_post AS
 SELECT comments.post_id,
    count(*) AS comments_count
   FROM public.comments
  GROUP BY comments.post_id;


ALTER TABLE public.avg_comments_per_post OWNER TO news_user;

--
-- Name: channels; Type: TABLE; Schema: public; Owner: news_user
--

CREATE TABLE public.channels (
    channel_id integer NOT NULL,
    name character varying(255) NOT NULL,
    link character varying(255),
    subscribers_count integer DEFAULT 0,
    source_id integer,
    topic character varying(255)
);


ALTER TABLE public.channels OWNER TO news_user;

--
-- Name: channels_channel_id_seq; Type: SEQUENCE; Schema: public; Owner: news_user
--

CREATE SEQUENCE public.channels_channel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channels_channel_id_seq OWNER TO news_user;

--
-- Name: channels_channel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: news_user
--

ALTER SEQUENCE public.channels_channel_id_seq OWNED BY public.channels.channel_id;


--
-- Name: comments_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: news_user
--

CREATE SEQUENCE public.comments_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comments_comment_id_seq OWNER TO news_user;

--
-- Name: comments_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: news_user
--

ALTER SEQUENCE public.comments_comment_id_seq OWNED BY public.comments.comment_id;


--
-- Name: comments_moving_avg; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.comments_moving_avg AS
 SELECT comments.post_id,
    comments.nickname,
    comments.created_at,
    avg(count(*)) OVER (PARTITION BY comments.post_id ORDER BY comments.created_at ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS moving_avg_comments
   FROM public.comments
  GROUP BY comments.post_id, comments.nickname, comments.created_at;


ALTER TABLE public.comments_moving_avg OWNER TO news_user;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: news_user
--

CREATE TABLE public.posts (
    post_id integer NOT NULL,
    title character varying(255) NOT NULL,
    author_id integer,
    text_id integer,
    channel_id integer,
    comments_count integer DEFAULT 0,
    likes_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.posts OWNER TO news_user;

--
-- Name: comments_posts_users; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.comments_posts_users AS
 SELECT c.comment_id,
    c.text,
    p.title AS post_title,
    c.nickname AS user_name
   FROM (public.comments c
     JOIN public.posts p ON ((c.post_id = p.post_id)));


ALTER TABLE public.comments_posts_users OWNER TO news_user;

--
-- Name: comments_with_users; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.comments_with_users AS
 SELECT c.comment_id,
    c.post_id,
    c.nickname AS user_name,
    c.text
   FROM public.comments c;


ALTER TABLE public.comments_with_users OWNER TO news_user;

--
-- Name: cumulative_posts; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.cumulative_posts AS
 SELECT posts.post_id,
    posts.author_id,
    posts.created_at,
    sum(1) OVER (PARTITION BY posts.author_id ORDER BY posts.created_at) AS cumulative_count
   FROM public.posts;


ALTER TABLE public.cumulative_posts OWNER TO news_user;

--
-- Name: post_tags; Type: TABLE; Schema: public; Owner: news_user
--

CREATE TABLE public.post_tags (
    post_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.post_tags OWNER TO news_user;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: news_user
--

CREATE TABLE public.tags (
    tag_id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.tags OWNER TO news_user;

--
-- Name: full_post_info; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.full_post_info AS
 SELECT p.post_id,
    p.title,
    a.name AS author,
    ch.name AS channel_name,
    t.name AS tag_name
   FROM ((((public.posts p
     JOIN public.authors a ON ((p.author_id = a.author_id)))
     JOIN public.channels ch ON ((p.channel_id = ch.channel_id)))
     JOIN public.post_tags pt ON ((p.post_id = pt.post_id)))
     JOIN public.tags t ON ((pt.tag_id = t.tag_id)));


ALTER TABLE public.full_post_info OWNER TO news_user;

--
-- Name: media; Type: TABLE; Schema: public; Owner: news_user
--

CREATE TABLE public.media (
    media_id integer NOT NULL,
    post_id integer,
    media_content character varying(255),
    media_type character varying(50) DEFAULT 'image'::character varying
);


ALTER TABLE public.media OWNER TO news_user;

--
-- Name: full_post_media; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.full_post_media AS
 SELECT p.post_id,
    p.title,
    a.name AS author,
    ch.name AS channel_name,
    t.name AS tag_name,
    m.media_content AS media_url
   FROM (((((public.posts p
     JOIN public.authors a ON ((p.author_id = a.author_id)))
     JOIN public.channels ch ON ((p.channel_id = ch.channel_id)))
     JOIN public.post_tags pt ON ((p.post_id = pt.post_id)))
     JOIN public.tags t ON ((pt.tag_id = t.tag_id)))
     JOIN public.media m ON ((m.post_id = p.post_id)));


ALTER TABLE public.full_post_media OWNER TO news_user;

--
-- Name: media_media_id_seq; Type: SEQUENCE; Schema: public; Owner: news_user
--

CREATE SEQUENCE public.media_media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_media_id_seq OWNER TO news_user;

--
-- Name: media_media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: news_user
--

ALTER SEQUENCE public.media_media_id_seq OWNED BY public.media.media_id;


--
-- Name: news_texts; Type: TABLE; Schema: public; Owner: news_user
--

CREATE TABLE public.news_texts (
    text_id integer NOT NULL,
    text text NOT NULL
);


ALTER TABLE public.news_texts OWNER TO news_user;

--
-- Name: news_texts_text_id_seq; Type: SEQUENCE; Schema: public; Owner: news_user
--

CREATE SEQUENCE public.news_texts_text_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.news_texts_text_id_seq OWNER TO news_user;

--
-- Name: news_texts_text_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: news_user
--

ALTER SEQUENCE public.news_texts_text_id_seq OWNED BY public.news_texts.text_id;


--
-- Name: popular_tags; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.popular_tags AS
 SELECT post_tags.tag_id,
    count(*) AS usage_count
   FROM public.post_tags
  GROUP BY post_tags.tag_id;


ALTER TABLE public.popular_tags OWNER TO news_user;

--
-- Name: posts_authors_channels; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.posts_authors_channels AS
 SELECT p.post_id,
    p.title,
    a.name AS author,
    ch.name AS channel_name
   FROM ((public.posts p
     JOIN public.authors a ON ((p.author_id = a.author_id)))
     JOIN public.channels ch ON ((p.channel_id = ch.channel_id)));


ALTER TABLE public.posts_authors_channels OWNER TO news_user;

--
-- Name: posts_authors_tags; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.posts_authors_tags AS
 SELECT p.post_id,
    p.title,
    a.name AS author,
    t.name AS tag_name
   FROM (((public.posts p
     JOIN public.authors a ON ((p.author_id = a.author_id)))
     JOIN public.post_tags pt ON ((p.post_id = pt.post_id)))
     JOIN public.tags t ON ((pt.tag_id = t.tag_id)));


ALTER TABLE public.posts_authors_tags OWNER TO news_user;

--
-- Name: posts_by_channel; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.posts_by_channel AS
 SELECT posts.channel_id,
    count(*) AS posts_count
   FROM public.posts
  GROUP BY posts.channel_id;


ALTER TABLE public.posts_by_channel OWNER TO news_user;

--
-- Name: posts_post_id_seq; Type: SEQUENCE; Schema: public; Owner: news_user
--

CREATE SEQUENCE public.posts_post_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_post_id_seq OWNER TO news_user;

--
-- Name: posts_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: news_user
--

ALTER SEQUENCE public.posts_post_id_seq OWNED BY public.posts.post_id;


--
-- Name: posts_ranked; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.posts_ranked AS
 SELECT posts.post_id,
    posts.author_id,
    posts.title,
    row_number() OVER (PARTITION BY posts.author_id ORDER BY posts.created_at DESC) AS rank_recent,
    count(*) OVER (PARTITION BY posts.author_id) AS total_posts
   FROM public.posts;


ALTER TABLE public.posts_ranked OWNER TO news_user;

--
-- Name: posts_with_authors; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.posts_with_authors AS
 SELECT p.post_id,
    p.title,
    a.name AS author
   FROM (public.posts p
     JOIN public.authors a ON ((p.author_id = a.author_id)));


ALTER TABLE public.posts_with_authors OWNER TO news_user;

--
-- Name: posts_with_tags; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.posts_with_tags AS
 SELECT p.post_id,
    p.title,
    t.name AS tag_name
   FROM ((public.posts p
     JOIN public.post_tags pt ON ((p.post_id = pt.post_id)))
     JOIN public.tags t ON ((pt.tag_id = t.tag_id)));


ALTER TABLE public.posts_with_tags OWNER TO news_user;

--
-- Name: sources; Type: TABLE; Schema: public; Owner: news_user
--

CREATE TABLE public.sources (
    source_id integer NOT NULL,
    name character varying(255) NOT NULL,
    address character varying(255) NOT NULL,
    topic character varying(255)
);


ALTER TABLE public.sources OWNER TO news_user;

--
-- Name: sources_source_id_seq; Type: SEQUENCE; Schema: public; Owner: news_user
--

CREATE SEQUENCE public.sources_source_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sources_source_id_seq OWNER TO news_user;

--
-- Name: sources_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: news_user
--

ALTER SEQUENCE public.sources_source_id_seq OWNED BY public.sources.source_id;


--
-- Name: tag_rank; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.tag_rank AS
 SELECT post_tags.tag_id,
    count(*) AS usage_count,
    rank() OVER (ORDER BY (count(*)) DESC) AS rank_usage
   FROM public.post_tags
  GROUP BY post_tags.tag_id;


ALTER TABLE public.tag_rank OWNER TO news_user;

--
-- Name: tags_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: news_user
--

CREATE SEQUENCE public.tags_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_tag_id_seq OWNER TO news_user;

--
-- Name: tags_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: news_user
--

ALTER SEQUENCE public.tags_tag_id_seq OWNED BY public.tags.tag_id;


--
-- Name: top_authors; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.top_authors AS
 SELECT posts.author_id,
    count(*) AS posts_count
   FROM public.posts
  GROUP BY posts.author_id;


ALTER TABLE public.top_authors OWNER TO news_user;

--
-- Name: user_activity_rank; Type: VIEW; Schema: public; Owner: news_user
--

CREATE VIEW public.user_activity_rank AS
 SELECT comments.nickname,
    count(*) AS comments_count,
    dense_rank() OVER (ORDER BY (count(*)) DESC) AS activity_rank
   FROM public.comments
  GROUP BY comments.nickname;


ALTER TABLE public.user_activity_rank OWNER TO news_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: news_user
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    username character varying(255),
    access_level character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO news_user;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: news_user
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO news_user;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: news_user
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: authors author_id; Type: DEFAULT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.authors ALTER COLUMN author_id SET DEFAULT nextval('public.authors_author_id_seq'::regclass);


--
-- Name: channels channel_id; Type: DEFAULT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.channels ALTER COLUMN channel_id SET DEFAULT nextval('public.channels_channel_id_seq'::regclass);


--
-- Name: comments comment_id; Type: DEFAULT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.comments ALTER COLUMN comment_id SET DEFAULT nextval('public.comments_comment_id_seq'::regclass);


--
-- Name: media media_id; Type: DEFAULT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.media ALTER COLUMN media_id SET DEFAULT nextval('public.media_media_id_seq'::regclass);


--
-- Name: news_texts text_id; Type: DEFAULT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.news_texts ALTER COLUMN text_id SET DEFAULT nextval('public.news_texts_text_id_seq'::regclass);


--
-- Name: posts post_id; Type: DEFAULT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.posts ALTER COLUMN post_id SET DEFAULT nextval('public.posts_post_id_seq'::regclass);


--
-- Name: sources source_id; Type: DEFAULT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.sources ALTER COLUMN source_id SET DEFAULT nextval('public.sources_source_id_seq'::regclass);


--
-- Name: tags tag_id; Type: DEFAULT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.tags ALTER COLUMN tag_id SET DEFAULT nextval('public.tags_tag_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: authors authors_name_key; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_name_key UNIQUE (name);


--
-- Name: authors authors_pkey; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_pkey PRIMARY KEY (author_id);


--
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (channel_id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (comment_id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (media_id);


--
-- Name: news_texts news_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.news_texts
    ADD CONSTRAINT news_texts_pkey PRIMARY KEY (text_id);


--
-- Name: post_tags post_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.post_tags
    ADD CONSTRAINT post_tags_pkey PRIMARY KEY (post_id, tag_id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (post_id);


--
-- Name: sources sources_pkey; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT sources_pkey PRIMARY KEY (source_id);


--
-- Name: tags tags_name_key; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_name_key UNIQUE (name);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (tag_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: channels channels_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(source_id) ON DELETE SET NULL;


--
-- Name: comments comments_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES public.comments(comment_id) ON DELETE CASCADE;


--
-- Name: comments comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(post_id) ON DELETE CASCADE;


--
-- Name: media media_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(post_id) ON DELETE CASCADE;


--
-- Name: post_tags post_tags_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.post_tags
    ADD CONSTRAINT post_tags_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(post_id) ON DELETE CASCADE;


--
-- Name: post_tags post_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.post_tags
    ADD CONSTRAINT post_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(tag_id) ON DELETE CASCADE;


--
-- Name: posts posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.authors(author_id) ON DELETE SET NULL;


--
-- Name: posts posts_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(channel_id) ON DELETE SET NULL;


--
-- Name: posts posts_text_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: news_user
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_text_id_fkey FOREIGN KEY (text_id) REFERENCES public.news_texts(text_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict xm4I2YHWqBPMFIcqGYTTFdeEn80R3OZHVb7CncuoURk9XWiXrBnNh9eWyaNEeqa

