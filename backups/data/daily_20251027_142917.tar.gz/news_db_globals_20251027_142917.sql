--
-- PostgreSQL database cluster dump
--

\restrict KvOpS7jrwzIoEpgS1TfdsGI1GVgVrfHFDgxSFUsL7gFlRB5cd7rpIZyP2J009EP

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE news_user;
ALTER ROLE news_user WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:2syf/9LcNGxpNczqwkHrWA==$ykQq1CBqayRoYEPr997mErwEeIE/TXP1kTcrURFWug0=:3/c41pFJiDsTiMMN24XXGkW/BeDnMU7nbBkC7n23Yjo=';

--
-- User Configurations
--








\unrestrict KvOpS7jrwzIoEpgS1TfdsGI1GVgVrfHFDgxSFUsL7gFlRB5cd7rpIZyP2J009EP

--
-- PostgreSQL database cluster dump complete
--

